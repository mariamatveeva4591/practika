# Листинг 1. Тестирование модели Tovar
# Описание: Проверка корректного создания объекта Tovar и вычисления цены со скидкой

from django.test import TestCase
from .models import Category, NameTovar, Producer, Supplier, Tovar, Role, User


class TovarModelTest(TestCase):
    """Тесты для модели товара"""

    def setUp(self):
        """Подготовка данных перед каждым тестом"""
        # Создание связанных объектов
        self.category = Category.objects.create(title="Женская обувь")
        self.name = NameTovar.objects.create(title="Ботинки")
        self.producer = Producer.objects.create(title="Производитель 1")
        self.supplier = Supplier.objects.create(title="Поставщик 1")

        # Создание товара со скидкой
        self.tovar = Tovar.objects.create(
            title=self.name,
            unit="пара",
            price=2000,
            supplier=self.supplier,
            producer=self.producer,
            category=self.category,
            discount=10,
            amount=15,
            description="Тестовый товар",
            photo="test.jpg"
        )

    def test_tovar_creation(self):
        """Проверка создания товара с корректными полями"""
        self.assertEqual(self.tovar.title.title, "Ботинки")
        self.assertEqual(self.tovar.category.title, "Женская обувь")
        self.assertEqual(self.tovar.price, 2000)
        self.assertEqual(self.tovar.discount, 10)
        self.assertEqual(self.tovar.amount, 15)



    # Листинг 2. Тестирование вычисления цены со скидкой
    # Описание: Проверка правильности расчета итоговой цены с учетом скидки

    def test_discount_price_calculation(self):
        """Проверка расчета цены со скидкой"""
        # Цена 2000, скидка 10% -> итоговая цена 1800
        expected_price = 2000 * (1 - 10 / 100)  # 1800
        discount_price = self.tovar.price * (1 - self.tovar.discount / 100)
        self.assertEqual(discount_price, expected_price)

    def test_tovar_without_discount(self):
        """Проверка товара без скидки"""
        tovar_no_discount = Tovar.objects.create(
            title=self.name,
            unit="пара",
            price=1500,
            supplier=self.supplier,
            producer=self.producer,
            category=self.category,
            discount=0,
            amount=10,
            description="Товар без скидки",
            photo="test2.jpg"
        )
        self.assertEqual(tovar_no_discount.discount, 0)
        self.assertEqual(tovar_no_discount.price, 1500)


# Листинг 3. Тестирование модели User
# Описание: Проверка создания пользователей с разными ролями

class UserModelTest(TestCase):
    """Тесты для модели пользователя"""

    def setUp(self):
        self.role_admin = Role.objects.create(title="Администратор")
        self.role_manager = Role.objects.create(title="Менеджер")
        self.role_client = Role.objects.create(title="Клиент")

    def test_create_admin_user(self):
        """Проверка создания пользователя с ролью администратора"""
        admin = User.objects.create(
            login="admin",
            password="12345",
            fio="Иванов Иван Иванович",
            role=self.role_admin
        )
        self.assertEqual(admin.login, "admin")
        self.assertEqual(admin.role.title, "Администратор")


    # Листинг 4. Тестирование методов модели User
    # Описание: Проверка методов для работы с паролем и ролями

    def test_password_check(self):
        """Проверка метода проверки пароля"""
        user = User.objects.create(
            login="test_user",
            password="correct_password",
            fio="Тестов Тест Тестович",
            role=self.role_client
        )

        # Проверка правильного пароля
        self.assertTrue(user.password == "correct_password")

        # Проверка неправильного пароля
        self.assertFalse(user.password == "wrong_password")

    def test_user_str_method(self):
        """Проверка строкового представления пользователя"""
        user = User.objects.create(
            login="test_user",
            password="12345",
            fio="Тестов Тест Тестович",
            role=self.role_client
        )
        self.assertIsNotNone(user.id)
        self.assertEqual(user.login, "test_user")